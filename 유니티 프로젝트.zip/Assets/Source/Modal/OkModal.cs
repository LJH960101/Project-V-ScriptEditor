﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OkModal : MonoBehaviour {
    public void Init(string text)
    {
        transform.Find("Image").Find("Text").GetComponent < UnityEngine.UI.Text>().text = text;
        transform.Find("Image").Find("Button").GetComponent<UnityEngine.UI.Button>().onClick.AddListener(Click);
        GetComponent<FadeOutSystem>().Init(4f, true, 1f, false);
        GetComponent<FadeOutSystem>().FadeIn();
    }
    public void Click()
    {
        GetComponent<FadeOutSystem>().FadeOut();
    }
}
