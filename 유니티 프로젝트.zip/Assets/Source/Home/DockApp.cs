﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using MyDesign;

public class DockApp : MonoBehaviour {
    [HideInInspector] public AppType appType;

    Home myHome;
    GameObject appText;
    UnityEngine.UI.Image appIcon_image, alarm_image;
    UnityEngine.UI.Text alarm_text;

    GameObject myApp;

    public void SetNotification(int num)
    {
        if (num > 0)
        {
            alarm_text.text = num + "";
            alarm_image.enabled = true;
        }
        else
        {
            alarm_text.text = "";
            alarm_image.enabled = false;
        }
    }
    void LinkDock()
    {
        myApp = myHome.transform.parent.Find(appType.ToString() + "Main").gameObject;
        myApp.GetComponent<AppMain>().Init(myHome, this);
        if (myApp.GetComponent<RandChatMain>()) myApp.GetComponent<RandChatMain>().Init();
        else if (myApp.GetComponent<MessangerMain>()) myApp.GetComponent<MessangerMain>().Init();
        else if (myApp.GetComponent<SnsMain>()) myApp.GetComponent<SnsMain>().Init();
        myApp.SetActive(false);
    }
    public void Click()
    {
        ReloadApp();
        myApp.GetComponent<FadeOutSystem>().SetType(FadeOutSystem.ChangeType.Zoom);
        myApp.GetComponent<FadeOutSystem>().FadeIn();
        myHome.fos.FadeOut();
    }
    public void ReloadApp()
    {
        if(myApp == RandChatMain.GetInstance().gameObject)
        {
            RandChatMain.GetInstance().Reload();
        }
        else if (myApp == MessangerMain.GetInstance().gameObject)
        {
            MessangerMain.GetInstance().Reload();
        }
        else if (myApp == SnsMain.GetInstance().gameObject)
        {
            SnsMain.GetInstance().Reload();
        }
    }
    public void SetTextActive(bool active)
    {
        appText.SetActive(active);
    }
    public void Init(AppType at, Home home)
    {
        appType = at;
        myHome = home;
        appText.GetComponent<UnityEngine.UI.Text>().text = at.ToString();
        LinkDock();

        switch (appType)
        {
            case AppType.Calculator:
                appText.GetComponent<UnityEngine.UI.Text>().text = "계산기";
                break;
            case AppType.Calender:
                appText.GetComponent<UnityEngine.UI.Text>().text = "달력";
                break;
            case AppType.Call:
                appText.GetComponent<UnityEngine.UI.Text>().text = "전화";
                break;
            case AppType.Clock:
                appText.GetComponent<UnityEngine.UI.Text>().text = "시간";
                break;
            case AppType.Contact:
                appText.GetComponent<UnityEngine.UI.Text>().text = "연락처";
                break;
            case AppType.Game:
                appText.GetComponent<UnityEngine.UI.Text>().text = "장조림을 찾아서";
                break;
            case AppType.Messenger:
                appText.GetComponent<UnityEngine.UI.Text>().text = "메신저";
                break;
            case AppType.Photo:
                appText.GetComponent<UnityEngine.UI.Text>().text = "앨범";
                break;
            case AppType.RandomChat:
                appText.GetComponent<UnityEngine.UI.Text>().text = "유리병";
                break;
            case AppType.Setting:
                appText.GetComponent<UnityEngine.UI.Text>().text = "설정";
                break;
            case AppType.Sns:
                appText.GetComponent<UnityEngine.UI.Text>().text = "linstagram";
                break;
        }
        appIcon_image.sprite = Resources.Load<Sprite>("UI/icons/" + appType.ToString());
    }

	// Use this for initialization
	void Awake () {
        appText = transform.Find("AppText").gameObject;
        appIcon_image = GetComponent<UnityEngine.UI.Image>();
        alarm_text = transform.Find("AlarmText").GetComponent<UnityEngine.UI.Text>();
        alarm_image = transform.Find("AlarmIcon").GetComponent<UnityEngine.UI.Image>();
        myApp = null;

        alarm_text.text = "";
        alarm_image.enabled = false;
    }
}
