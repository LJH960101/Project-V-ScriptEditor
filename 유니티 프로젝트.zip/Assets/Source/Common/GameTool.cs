﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MyDesign;
using System;

namespace MyTool
{
    public static class ToolClass
    {
        static public string MakeStringPretty(string orginString, int lineLimit = 9999, bool bOnRemove = true, int rowLimit = 9999)
        {
            string newText = orginString;
            int count = 0;
            
            // 한줄당 N개의 글자수로 제한
            for (int i = 0; i < newText.Length; ++i)
            {
                ++count;
                if (newText[i] == '\n')
                {
                    count = 0;
                }
                if (count >= lineLimit)
                {
                    // 지우기
                    if (bOnRemove)
                    {
                        newText = newText.Remove(i, 1);
                        --i;
                    }
                    // 줄바꾸기
                    else
                    {
                        if (i == newText.Length - 1) break;
                        newText = newText.Insert(i, "\n");
                        count = 0;
                    }
                    continue;
                }
            }
            count = 0;

            // rowLimit 줄로 자름
            for (int i = 0; i < newText.Length; ++i)
            {
                if (newText[i] == '\n')
                {
                    ++count;
                    if (count >= rowLimit)
                    {
                        newText = newText.Substring(0, i);
                        break;
                    }
                }
            }

            return newText;
        }
        static public void MakeNotify(AppType appCode, string text, int code = -1)
        {
            GameMain gm = GameMain.GetInstance();
            if (gm.currentApp && (gm.currentApp.GetComponent<Home>() || gm.currentApp.GetComponent<AppMain>().appType != appCode))
            {
                gm.notify.ShowNotify(appCode, text, code);
            }
        }
        static public String ParseToSmallScript(string script)
        {
            ScriptParsedData spd = ParseScript(script);
            switch (spd.type)
            {
                case ScriptType.NORMAL:
                    return spd.val;
                case ScriptType.PHOTO:
                    return "(사진)";
                case ScriptType.PROFILE:
                    return "(프로필)";
                case ScriptType.ADRESS:
                    return "(주소)";
                default:
                    return "";
            }
        }
        static public ScriptParsedData ParseScript(string script)
        {
            string upperString = script.ToUpper();
            ScriptParsedData returnData = new ScriptParsedData();
            // 특수 채팅
            if (upperString[0] == '[')
            {
                if (upperString == "[PC]")
                {
                    returnData.type = ScriptType.PC_START;
                }
                else if (upperString == "[NPC]")
                {
                    returnData.type = ScriptType.NPC_START;
                }
                else if (upperString == "[SE]")
                {
                    returnData.type = ScriptType.SELECT_END;
                }
                else if (upperString == "[L]")
                {
                    returnData.type = ScriptType.LINE;
                }
                else if (upperString == "[D]")
                {
                    returnData.type = ScriptType.DEAD;
                }
                else if (upperString == "[PR]")
                {
                    returnData.type = ScriptType.PROFILE;
                }
                else if (upperString == "[AD]")
                {
                    returnData.type = ScriptType.ADRESS;
                }
                else if (upperString[1] == 'I' && upperString[2] == 'F')
                {
                    string removeNeedString = "[IF ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.IF;
                    returnData.val = script;
                }
                else if (upperString[1] == 'L' && upperString[2] == 'I')
                {
                    string removeNeedString = "[LIKE ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.Like;
                    returnData.val = script;
                }
                else if (upperString[1] == 'C' && upperString[2] == 'O')
                {
                    string removeNeedString = "[COMMENT ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.COMMENT;
                    returnData.val = script;
                }
                else if (upperString[1] == 'W')
                {
                    string removeNeedString = "[W ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.WAIT;
                    returnData.val = script;
                }
                else if (upperString[1] == 'L' && upperString[2] == ' ')
                {
                    string removeNeedString = "[L ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.LOVE;
                    returnData.val = script;
                }
                else if (upperString[1] == 'S' && upperString[2] == ' ')
                {
                    string removeNeedString = "[S ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.SELECT_LIST;
                    returnData.val = script;
                }
                else if (upperString[1] == 'S' && upperString[2] == 'S')
                {
                    string removeNeedString = "[SS ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.SELECT_START;
                    returnData.val = script;
                }
                else if (upperString[1] == 'P' && upperString[2] == 'H')
                {
                    string removeNeedString = "[PH ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.PHOTO;
                    returnData.val = script;
                }
                else if (upperString[1] == 'C' && upperString[2] == 'N')
                {
                    string removeNeedString = "[CN ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.CHANGE_NAME;
                    returnData.val = script;
                }
                else if (upperString[1] == 'C' && upperString[2] == 'P')
                {
                    string removeNeedString = "[CP ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.CHANGE_PHOTO;
                    returnData.val = script;
                }
                else if (upperString[1] == 'C' && upperString[2] == 'S')
                {
                    string removeNeedString = "[CS ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.CHANGE_STATUS;
                    returnData.val = script;
                }
                else if (upperString[1] == 'G' && upperString[2] == 'L')
                {
                    string removeNeedString = "[GL ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.GOTO_LINE;
                    returnData.val = script;
                }
                else if (upperString[1] == 'T' && upperString[2] == 'O')
                {
                    string removeNeedString = "[TO ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.TRIGGER_ON;
                    returnData.val = script;
                }
                else if (upperString[1] == 'T' && upperString[2] == 'X')
                {
                    string removeNeedString = "[TX ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.TRIGGER_OFF;
                    returnData.val = script;
                }
                else if (upperString[1] == 'W' && upperString[2] == 'T')
                {
                    string removeNeedString = "[WT ";
                    int i = upperString.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);
                    removeNeedString = "]";
                    i = script.IndexOf(removeNeedString);
                    script = script.Remove(i, removeNeedString.Length);

                    returnData.type = ScriptType.WAIT_TRIGGER;
                    returnData.val = script;
                }
            }
            else
            {
                string newString = script.Replace("$NAME", GameMain.GetInstance().mainData.msgName);
                newString = newString.Replace("$ID", GameMain.GetInstance().mainData.snsId);

                returnData.type = ScriptType.NORMAL;
                returnData.val = newString;
            }

            return returnData;
        }
        static public ChatType GetCharacterChatType(int charCode)
        {
            MainData mainData = GameMain.GetInstance().mainData;
            foreach (MyCharacter character in mainData.characters)
            {
                if (character.charCode == charCode)
                {
                    if (character.bOnChat)
                    {
                        return ChatType.CHAT;
                    }
                    else if (character.bOnRand && !character.bOnChat)
                    {
                        return ChatType.RANDCHAT;
                    }
                    else if (!character.bOnRand && !character.bOnChat)
                    {
                        return ChatType.NO_CHAT;
                    }
                }
            }
            throw new Exception("There's no matched charcode.");
        }
        static public ChatType GetCharacterChatType(MyCharacter character)
        {
            if (character.bOnChat)
            {
                return ChatType.CHAT;
            }
            else if (character.bOnRand && !character.bOnChat)
            {
                return ChatType.RANDCHAT;
            }
            else if (!character.bOnRand && !character.bOnChat)
            {
                return ChatType.NO_CHAT;
            }
            throw new Exception("There's no matched charcode.");
        }
        public static string GetName(int charCode, ChatType chatType)
        {
            MainData mainData = GameMain.GetInstance().mainData;
            for (int i = 0; i < mainData.characters.Count; ++i)
            {
                if (charCode == mainData.characters[i].charCode)
                {
                    switch (chatType)
                    {
                        case ChatType.RANDCHAT:
                            return "낯선 사람";
                        //return mainData.characters[i].randName;
                        case ChatType.CHAT:
                            return mainData.characters[i].name;
                        case ChatType.SNS:
                            return mainData.characters[i].snsId;
                    }
                }
            }
            return "Wrong Code";
        }
        static public ChatScript GetScript(int scriptCode)
        {
            MainData mainData = GameMain.GetInstance().mainData;
            foreach (ChatScript script in mainData.scripts)
            {
                if (script.scriptCode == scriptCode)
                    return script;
            }
            throw new Exception("None exist scriptcode (" + scriptCode + ")");
        }
        static public MyCharacter GetCharacter(int charCode)
        {
            MainData mainData = GameMain.GetInstance().mainData;
            foreach (MyCharacter ch in mainData.characters)
            {
                if (ch.charCode == charCode)
                    return ch;
            }
            throw new Exception("None exist charcode (" + charCode + ")");
        }
        static public SnsPostData GetSnsPost(int postCode)
        {
            MainData mainData = GameMain.GetInstance().mainData;
            foreach (SnsPostData spd in mainData.posts)
            {
                if (spd.postCode == postCode)
                    return spd;
            }
            throw new Exception("None exist postcode (" + postCode + ")");
        }
        static public SnsLog GetSnsPostLog(int postCode)
        {
            MainData mainData = GameMain.GetInstance().mainData;
            foreach (SnsLog spd in mainData.snsLogs)
            {
                if (spd.postCode == postCode)
                    return spd;
            }
            throw new Exception("None exist postcode (" + postCode + ")");
        }
    }
}
