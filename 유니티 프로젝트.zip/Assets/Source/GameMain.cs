﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using MyDesign;
using MyTool;
using Assets.SimpleAndroidNotifications;
using UnityEngine.SceneManagement;
#if UNITY_STANDALONE_WIN || UNITY_EDITOR
using UnityEngine.Windows;
using System.IO;
#endif

public class GameMain : MonoBehaviour {
    const float touchEffect_respawnTime = 0.05f;

    [HideInInspector] public GameObject currentApp;
    [HideInInspector] public MainData mainData;
    [HideInInspector] public List<MyCharacter> charcaters;
    [HideInInspector] public Notify notify;

    bool bOnTouch;
    Int32 myTouchid;
    Vector2 nowPoint;
    GameObject pt_move, pt_touchEnd;
    float touchEffect_respawn;
    RandChatMain rcm;
    MessangerMain msg;

    void Awake() {
        ApplicationChrome.statusBarState = ApplicationChrome.States.Visible;
        bOnTouch = false;
        myTouchid = -1;
        touchEffect_respawn = 0f;
        mainData.snsId = "ljh960101";
        pt_move = Resources.Load<GameObject>("Prefab/Main/PT_Move");
        pt_touchEnd = Resources.Load<GameObject>("Prefab/Main/PT_TouchEnd");
        notify = transform.Find("Notify").GetComponent<Notify>();
        if (transform.Find("AppScreen")) rcm = transform.Find("AppScreen").Find("RandomChatMain").GetComponent<RandChatMain>();
        else rcm = transform.Find("RandomChatMain").GetComponent<RandChatMain>();
        msg = MessangerMain.GetInstance();
        mainData.trigger = new Dictionary<int, bool>();
        mainData.msgName = "[Default]";
        ///////// RANDOM CHAT TEST
        mainData.characters = new List<MyCharacter>();
        mainData.scripts = new List<ChatScript>();
        mainData.snsLogs = new List<SnsLog>();
        mainData.snsAlrams = new List<SnsAlram>();

        if (!GetComponent<ScriptMaker>() && !GetComponent<SnsMaker>())
        {
            mainData.posts = new List<SnsPostData>();
            for (int i = 1; i <= 0; ++i)
            {
                SnsPostData spd = new SnsPostData();
                spd.content = "테스트\n너모 싫다\n시밤바";
                spd.defaulatLike = 5;
                spd.level = 0;
                spd.picCode = "sw_02";
                spd.postCode = i;
                spd.charCode = 1;
                spd.postScripts = new List<PostScript>();
                PostScript test = new PostScript();
                test.currentPos = 0;
                test.currentProcess = 0f;
                test.isOver = false;
                test.scripts = new List<string>();
                test.scripts.Add("[SS 안녕$하세$요?]");
                test.scripts.Add("[S 안녕]");
                test.scripts.Add("[COMMENT @ljh960101$S1]");
                test.scripts.Add("[S 하세]");
                test.scripts.Add("[COMMENT @lol123$S2]");
                test.scripts.Add("[S 요?]");
                test.scripts.Add("[COMMENT @DA$S3]");
                test.scripts.Add("[SE]");
                test.scripts.Add("[COMMENT @lol123$끝]");
                spd.postScripts.Add(test);
                spd.priority = 0;
                mainData.posts.Add(spd);
            }
        }

#if UNITY_STANDALONE_WIN || UNITY_EDITOR
        if (!GetComponent<ScriptMaker>() && !GetComponent<SnsMaker>())
        {
            if (File.Exists("scriptData.txt") && File.Exists("characterData.txt"))
            {
                mainData.scripts.AddRange(JsonUtility.FromJson<ScriptJsonData>(File.ReadAllText("scriptData.txt")).scripts);
                mainData.characters.AddRange(JsonUtility.FromJson<CharaterJsonData>(File.ReadAllText("characterData.txt")).characters);
                mainData.posts.AddRange(JsonUtility.FromJson<SnsJsonData>(File.ReadAllText("postData.txt")).posts);
            }
            else
            {
                mainData.scripts.AddRange(JsonUtility.FromJson<ScriptJsonData>(Resources.Load<TextAsset>("Data/scriptData").text).scripts);
                mainData.characters.AddRange(JsonUtility.FromJson<CharaterJsonData>(Resources.Load<TextAsset>("Data/characterData").text).characters);
                mainData.posts.AddRange(JsonUtility.FromJson<SnsJsonData>(Resources.Load<TextAsset>("Data/postData").text).posts);
            }
        }
#else
                mainData.scripts.AddRange(JsonUtility.FromJson<ScriptJsonData>(Resources.Load<TextAsset>("Data/scriptData").text).scripts);
                mainData.characters.AddRange(JsonUtility.FromJson<CharaterJsonData>(Resources.Load<TextAsset>("Data/characterData").text).characters);
                mainData.posts.AddRange(JsonUtility.FromJson<SnsJsonData>(Resources.Load<TextAsset>("Data/postData").text).posts);
#endif

        foreach (MyCharacter character in mainData.characters)
        {
            if (character.currentScriptCode != 0)
            {
                ChatScript myScript = ToolClass.GetScript(character.currentScriptCode);
                character.level = myScript.level;
                character.scriptPriority = myScript.priority;
            }
        }

        foreach (MyCharacter character in mainData.characters)
        {
            character.scriptCheck = new Dictionary<int, bool>();
        }

        /*mainData.msgName = "안뇽";
        MyCharacter testCharacter = new MyCharacter();
        testCharacter.charCode = 1;
        testCharacter.curMsgPic = 1;
        testCharacter.love = 0;
        testCharacter.level = 1;
        testCharacter.name = "이름";
        testCharacter.snsName = "인스타이름";
        testCharacter.statusMsg = "ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ\nㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ\nㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ";
        testCharacter.bOnRand = true;
        testCharacter.bOnChat = true;
        testCharacter.bOpenSns = false;
        testCharacter.scriptCheck = new Dictionary<int, bool>();
        testCharacter.currentScriptCode = 1;
        testCharacter.currentScriptPosition = 0;
        testCharacter.currentScriptProcess = 0;
        testCharacter.isGuest = false;
        testCharacter.scriptPriority = 0;
        testCharacter.onOverlapScript = false;
        mainData.characters.Add(testCharacter);
        {
            ChatScript testScript = new ChatScript();
            testScript.charCode = 1;
            testScript.scriptCode = 1;
            testScript.isMain = false;
            testScript.isOnlyOneTime = false;
            testScript.priority = 0;
            testScript.level = 1;
            testScript.otherLevelLimits = new List<OtherLevelLimit>();
            testScript.scripts = new List<string>();
            testScript.scripts.Add("[W 1]");
            testScript.scripts.Add("[NPC]");
            testScript.scripts.Add("안녕?");
            for(int i=0; i<1; ++i)
            {
                testScript.scripts.Add(i+"번");
            }
            testScript.scripts.Add("잘 ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ\nㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ\nㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ\nㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ\nㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ\nㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ\nㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ");
            testScript.scripts.Add("[W 3]");
            testScript.scripts.Add("[SS 누구세요??$안녕?]");
            testScript.scripts.Add("[S 누구세요??]");
            testScript.scripts.Add("누구세요??");
            //testScript.scripts.Add("[W 3]");
            testScript.scripts.Add("[NPC]");
            testScript.scripts.Add("나도 모르겠어...");
            testScript.scripts.Add("[S 안녕?]");
            testScript.scripts.Add("안녕?");
            testScript.scripts.Add("ㅋㅋㅋ");
            testScript.scripts.Add("[SE]");
            //testScript.scripts.Add("[W 2]");
            testScript.scripts.Add("[NPC]");
            testScript.scripts.Add("잘 지내보자.");

            testScript.scriptEventType = ScriptEventType.NORMAL;
            mainData.scripts.Add(testScript);
        }*/

        /*ChatLog chatlog = new ChatLog();
        chatlog.charCode = 1;
        chatlog.beforeChats = new List<BeforeChat>();
        BeforeChat a = new BeforeChat();
        a.chat = "1";
        a.date = DateTime.Now;
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        chatlog.beforeChats.Add(a);
        mainData.randomChatLogs.Add(chatlog);
        mainData.randomChatLogs.Add(chatlog);
        mainData.randomChatLogs.Add(chatlog);
        mainData.randomChatLogs.Add(chatlog);
        mainData.randomChatLogs.Add(chatlog);
        mainData.randomChatLogs.Add(chatlog);
        mainData.randomChatLogs.Add(chatlog);
        mainData.randomChatLogs.Add(chatlog);
        mainData.randomChatLogs.Add(chatlog);
        mainData.randomChatLogs.Add(chatlog);*/
    }
    void Update()
    {
        TouchEffectProc();
        GameProc();
    }

    [HideInInspector] public float typingSpeed = 4.7f;
    bool skip = false;
    // 채팅을 진행한다.
    void GameProc()
    {
        // SNS 해금 처리
        foreach (var post in mainData.posts)
        {
            if (!post.isPosted)
            {
                MyCharacter character = ToolClass.GetCharacter(post.charCode);
                if(character.level>=post.level && character.scriptPriority >= post.priority && character.bOnSns)
                {
                    SnsMain.GetInstance().MakeLog(post);
                }
            }
        }

        // SNS 스크립트 진행
        foreach(var postLog in mainData.snsLogs)
        {
            SnsPostData spd = ToolClass.GetSnsPost(postLog.postCode);
            if(!spd.isPosted || spd.isOver) continue;

            bool isOver = true;
            foreach(var postScript in spd.postScripts)
            {
                if(postScript.isOver) continue;
                isOver = false;

                string currentScript = postScript.scripts[postScript.currentPos];
                ScriptParsedData parsedScript = ToolClass.ParseScript(currentScript);
                switch (parsedScript.type)
                {
                    case ScriptType.LOVE:
                        ToolClass.GetCharacter(spd.charCode).love += int.Parse(parsedScript.val);
                        ++postScript.currentPos;
                        postScript.currentProcess = 0f;
                        break;
                    case ScriptType.IF:
                        {
                            string[] condition = parsedScript.val.Split('$');
                            MyCharacter targetCharacter = ToolClass.GetCharacter(int.Parse(condition[0]));
                            if (targetCharacter.level >= int.Parse(condition[1]) &&
                                targetCharacter.scriptPriority >= int.Parse(condition[2]) &&
                                targetCharacter.love >= int.Parse(condition[3]))
                            {
                                ++postScript.currentPos;
                                postScript.currentProcess = 0f;
                            }
                            break;
                        }
                    case ScriptType.WAIT:
                        {
                            {
                                // 처음이라면 알림을 등록해준다.
                                if (postScript.currentProcess <= 0.5f)
                                {
                                    if (postScript.currentPos + 1 < postScript.scripts.Count)
                                    {
                                        for (int i = postScript.currentPos + 1; i < postScript.scripts.Count; ++i)
                                        {
                                            ScriptParsedData spd2 = ToolClass.ParseScript(postScript.scripts[i]);
                                            if (spd2.type == ScriptType.WAIT || spd2.type == ScriptType.SELECT_START || spd2.type == ScriptType.SELECT_LIST || spd2.type == ScriptType.SELECT_END || spd2.type == ScriptType.IF || spd2.type == ScriptType.SELECT_END) break;
                                            else if (spd2.type == ScriptType.COMMENT)
                                            {
                                                var notificationParams = new NotificationParams
                                                {
                                                    Id = UnityEngine.Random.Range(0, int.MaxValue),
                                                    Delay = TimeSpan.FromSeconds(float.Parse(parsedScript.val) + 0.5f),
                                                    Title = "내 폰 속 로맨틱",
                                                    Message = "새로운 게시글이 등록되었습니다!",
                                                    Ticker = "새로운 게시글이 등록되었습니다!",
                                                    Sound = true,
                                                    Vibrate = true,
                                                    Light = true,
                                                    SmallIcon = NotificationIcon.Heart,
                                                    SmallIconColor = new Color(0, 0.5f, 0),
                                                    LargeIcon = "app_icon"
                                                };
                                                NotificationManager.SendCustom(notificationParams);
                                                break;
                                            }
                                        }
                                    }
                                    postScript.currentProcess += 1f;
                                }

                                postScript.currentProcess += Time.deltaTime;
                                if (postScript.currentProcess >= float.Parse(parsedScript.val) + 1f || skip)
                                {
                                    ++postScript.currentPos;
                                    postScript.currentProcess = 0f;
                                }
                            }
                            break;
                        }
                    case ScriptType.COMMENT:
                        {
                            SnsMain sm = SnsMain.GetInstance();
                            string[] data = parsedScript.val.Split('$');

                            // Get Lasted Comment
                            string lastCharacterId = "";
                            for(int i=postScript.currentPos-1; i>=0; --i)
                            {
                                if(ToolClass.ParseScript(postScript.scripts[i]).type == ScriptType.COMMENT)
                                {
                                    string charId = ToolClass.ParseScript(postScript.scripts[i]).val.Split('$')[0];
                                    if(charId == "0")
                                    {
                                        lastCharacterId = "@" + mainData.snsId + " ";
                                        break;
                                    }
                                    else if (charId[0] == '@')
                                    {
                                        lastCharacterId = charId + " ";
                                    }
                                    else
                                    {
                                        lastCharacterId = '@' + ToolClass.GetCharacter(int.Parse(charId)).snsId + " ";
                                    }
                                }
                            }

                            SnsMain.GetInstance().AddComment(postLog.postCode, data[1], data[0], lastCharacterId);
                            NotificationManager.CancelAll();
                            ++postScript.currentPos;
                            postScript.currentProcess = 0f;
                            break;
                        }
                    case ScriptType.SELECT_START:
                        {
                            if (postScript.currentProcess == 0f)
                            {
                                postScript.currentProcess = 1f;
                                SnsMain.GetInstance().Resort();
                            }
                            break;  
                        }
                    case ScriptType.SELECT_LIST:
                        {
                            // SE를 만날떄까지 이동
                            for (int k = postScript.currentPos + 1; k < postScript.scripts.Count; ++k)
                            {
                                ScriptParsedData scriptData = ToolClass.ParseScript(postScript.scripts[k]);
                                if (scriptData.type == ScriptType.SELECT_END)
                                {
                                    postScript.currentPos = k + 1;
                                    postScript.currentProcess = 0f;
                                    break;
                                }
                            }
                            break;
                        }
                    case ScriptType.SELECT_END:
                        {
                            ++postScript.currentPos;
                            postScript.currentProcess = 0f;
                            break;
                        }
                    case ScriptType.Like:
                        {
                            postLog.like += int.Parse(parsedScript.val);
                            ++postScript.currentPos;
                            postScript.currentProcess = 0f;
                            break;
                        }
                }
                if (postScript.currentPos >= postScript.scripts.Count)
                {
                    --postScript.currentPos;
                    postScript.isOver = true;
                }
            }

            if (isOver) spd.isOver = true;
        }

        // 채팅 스크립트 진행
        foreach (MyCharacter character in mainData.characters)
        {
            // 스크립트 진행중
            if (character.currentScriptCode != 0)
            {
                ChatScript currentScript = ToolClass.GetScript(character.currentScriptCode);

                // 스크립트 종료
                if (character.currentScriptPosition >= currentScript.scripts.Count)
                {
                    if(ToolClass.GetCharacterChatType(character) != ChatType.RANDCHAT) SendToChatLog("[L]", character.charCode);
                    SendToChatLog("[W 7]", character.charCode);
                    GotoNextScript(character);
                    continue;
                }

                // 스크립트 진행
                ScriptParsedData script = ToolClass.ParseScript(currentScript.scripts[character.currentScriptPosition]);
                try
                {
                    switch (script.type)
                    {
                        case ScriptType.LOVE:
                            character.love += int.Parse(script.val);
                            ++character.currentScriptPosition;
                            character.currentScriptProcess = 0f;
                            break;
                        case ScriptType.WAIT:
                            {
                                // 처음이라면 알림을 등록해준다.
                                if (character.currentScriptProcess <= 0.5f)
                                {
                                    if (character.currentScriptPosition + 1 < currentScript.scripts.Count)
                                    {
                                        // NPC가 대화할때인지 판별해서 준다.
                                        bool lastIsPC = true;
                                        for (int i = character.currentScriptPosition - 1; i >= 0; --i)
                                        {
                                            ScriptParsedData spd = ToolClass.ParseScript(currentScript.scripts[i]);
                                            if (spd.type == ScriptType.PC_START) break;
                                            else if (spd.type == ScriptType.NPC_START)
                                            {
                                                lastIsPC = false;
                                                break;
                                            }
                                        }
                                        for (int i = character.currentScriptPosition + 1; i < currentScript.scripts.Count; ++i)
                                        {
                                            ScriptParsedData spd = ToolClass.ParseScript(currentScript.scripts[i]);
                                            if (spd.type == ScriptType.WAIT || spd.type == ScriptType.SELECT_START || spd.type == ScriptType.SELECT_LIST || spd.type == ScriptType.SELECT_END) break;
                                            else if (spd.type == ScriptType.NPC_START) lastIsPC = false;
                                            else if (spd.type == ScriptType.PC_START) lastIsPC = true;
                                            else if (spd.type == ScriptType.ADRESS || spd.type == ScriptType.NORMAL || spd.type == ScriptType.PHOTO || spd.type == ScriptType.PROFILE)
                                            {
                                                if (lastIsPC) break;
                                                var notificationParams = new NotificationParams
                                                {
                                                    Id = UnityEngine.Random.Range(0, int.MaxValue),
                                                    Delay = TimeSpan.FromSeconds(float.Parse(script.val) + 1f),
                                                    Title = "내 폰 속 로맨틱",
                                                    Message = "새로운 메시지가 도착하였습니다!",
                                                    Ticker = "새로운 메시지가 도착하였습니다!",
                                                    Sound = true,
                                                    Vibrate = true,
                                                    Light = true,
                                                    SmallIcon = NotificationIcon.Heart,
                                                    SmallIconColor = new Color(0, 0.5f, 0),
                                                    LargeIcon = "app_icon"
                                                };
                                                NotificationManager.SendCustom(notificationParams);
                                                break;
                                            }
                                        }
                                    }
                                    character.currentScriptProcess += 1f;
                                }

                                character.currentScriptProcess += Time.deltaTime;
                                if (character.currentScriptProcess >= float.Parse(script.val) + 1f || skip)
                                {
                                    ++character.currentScriptPosition;
                                    character.currentScriptProcess = 0f;
                                }
                            }
                            break;
                        case ScriptType.PC_START:
                        case ScriptType.NPC_START:
                        case ScriptType.PHOTO:
                        case ScriptType.PROFILE:
                        case ScriptType.ADRESS:
                        case ScriptType.LINE:
                            NotificationManager.CancelAll();
                            SendToChatLog(currentScript.scripts[character.currentScriptPosition], character.charCode);
                            ++character.currentScriptPosition;
                            character.currentScriptProcess = 0f;
                            break;
                        case ScriptType.NORMAL:
                            {
                                NotificationManager.CancelAll();
                                bool lastIsPC = false;
                                for (int i = character.currentScriptPosition - 1; i >= 0; i--)
                                {
                                    if (ToolClass.ParseScript(currentScript.scripts[i]).type == ScriptType.PC_START)
                                    {
                                        lastIsPC = true;
                                        break;
                                    }
                                    if (ToolClass.ParseScript(currentScript.scripts[i]).type == ScriptType.NPC_START)
                                    {
                                        lastIsPC = false;
                                        break;
                                    }
                                }
                                if (lastIsPC)
                                {
                                    if (ToolClass.GetCharacterChatType(character) == ChatType.RANDCHAT && rcm.currentScreen == RandChatMain.ERandomChatScreen.CHAT && rcm.chattingTargetCharCode == character.charCode && currentApp == rcm.gameObject)
                                    {
                                        character.currentScriptProcess += Time.deltaTime * typingSpeed;
                                        if (script.val.Length <= (int)character.currentScriptProcess - 1)
                                        {
                                            SendToChatLog(currentScript.scripts[character.currentScriptPosition], character.charCode);
                                            ++character.currentScriptPosition;
                                            character.currentScriptProcess = 0f;
                                            rcm.SetTypeText("");
                                            rcm.ScrollDown();
                                        }
                                        else
                                        {
                                            rcm.SetTypeText(script.val.Substring(0, (int)character.currentScriptProcess));
                                        }
                                    }
                                    else if (ToolClass.GetCharacterChatType(character) == ChatType.CHAT && msg.currentScreen == MessangerMain.EMSGScreen.CHAT && msg.chattingTargetCharCode == character.charCode && currentApp == msg.gameObject)
                                    {
                                        character.currentScriptProcess += Time.deltaTime * typingSpeed;
                                        if (script.val.Length <= (int)character.currentScriptProcess - 1)
                                        {
                                            SendToChatLog(currentScript.scripts[character.currentScriptPosition], character.charCode);
                                            ++character.currentScriptPosition;
                                            character.currentScriptProcess = 0f;
                                            msg.SetTypeText("");
                                            msg.ScrollDown();
                                        }
                                        else
                                        {
                                            msg.SetTypeText(script.val.Substring(0, (int)character.currentScriptProcess));
                                        }
                                    }
                                }
                                else
                                {
                                    SendToChatLog(currentScript.scripts[character.currentScriptPosition], character.charCode);
                                    ++character.currentScriptPosition;
                                    character.currentScriptProcess = 0f;
                                }
                            }
                            break;
                        case ScriptType.CHANGE_NAME:
                            character.name = script.val;
                            ++character.currentScriptPosition;
                            character.currentScriptProcess = 0f;
                            break;
                        case ScriptType.GOTO_LINE:
                            character.currentScriptPosition = int.Parse(script.val);
                            character.currentScriptProcess = 0f;
                            break;
                        case ScriptType.CHANGE_STATUS:
                            character.statusMsg = script.val;
                            ++character.currentScriptPosition;
                            character.currentScriptProcess = 0f;
                            break;
                        case ScriptType.CHANGE_PHOTO:
                            character.curMsgPic = script.val;
                            ++character.currentScriptPosition;
                            character.currentScriptProcess = 0f;
                            break;
                        case ScriptType.SELECT_LIST:
                            // SE를 만날떄까지 이동
                            for (int k = character.currentScriptPosition + 1; k < currentScript.scripts.Count; ++k)
                            {
                                ScriptParsedData scriptData = ToolClass.ParseScript(currentScript.scripts[k]);
                                if (scriptData.type == ScriptType.SELECT_END)
                                {
                                    character.currentScriptPosition = k + 1;
                                    character.currentScriptProcess = 0f;
                                    break;
                                }
                            }
                            break;
                        case ScriptType.SELECT_END:
                            ++character.currentScriptPosition;
                            character.currentScriptProcess = 0f;
                            break;
                        case ScriptType.SELECT_START:
                            if (character.currentScriptProcess != 1f)
                            {
                                character.currentScriptProcess = 1f;
                                SendToChatLog(currentScript.scripts[character.currentScriptPosition], character.charCode);
                            }
                            break;
                        case ScriptType.DEAD:
                            if (ToolClass.GetCharacterChatType(character) == ChatType.RANDCHAT)
                            {
                                rcm.ExitChatByChar(character.charCode);
                            }
                            break;
                        case ScriptType.TRIGGER_ON:
                            mainData.trigger[int.Parse(script.val)] = true;
                            ++character.currentScriptPosition;
                            character.currentScriptProcess = 0f;
                            break;
                        case ScriptType.TRIGGER_OFF:
                            mainData.trigger[int.Parse(script.val)] = false;
                            ++character.currentScriptPosition;
                            character.currentScriptProcess = 0f;
                            break;
                        case ScriptType.WAIT_TRIGGER:
                            int pos = int.Parse(script.val);
                            if (mainData.trigger[pos] && mainData.trigger[pos] == true)
                            {
                                ++character.currentScriptPosition;
                                character.currentScriptProcess = 0f;
                            }
                            break;
                    }
                }
                catch
                {
                    Modal.GetInstance().CreateNewOkModal("(" + character.currentScriptCode + ")" + character.currentScriptPosition+1 + "줄에서 오류 발생");
                }
            }
        }
    }
    public void GotoScriptMaker()
    {
        SceneManager.LoadScene("DeveloperMenu");
    }
    public void SpeedChange(bool val)
    {
        if (val)
        {
            typingSpeed = 4.7f;
            skip = false;
        }
        else
        {
            typingSpeed = 100f;
            skip = true;
        }
    }
    public void Test()
    {
        SnsMain.GetInstance().Resort();
        /*
        BeforeChat bc = new BeforeChat();
        bc.chat = "[Ph 1]";
        bc.date = DateTime.Now;
        mainData.randomChatLogs[0].beforeChats.Add(bc);
        rcm.Resort();*/

        /*ChatLog item = new ChatLog();
        BeforeChat bc = new BeforeChat();
        bc.chat = "12";
        bc.date = DateTime.Now;
        item.charCode = 1;
        item.beforeChats = new List<BeforeChat>();
        item.beforeChats.Add(bc);
        mainData.randomChatLogs.Add(item);
        rcm.Resort();*/

        /*++TTT;
        SendToChatLog(TTT +"\n2\n2\n4\n\n6", 1);*/
    }

    // 다음 스크립트로 넘겨줌
    public void GotoNextScript(MyCharacter character)
    {
        // 랜덤 채팅 상태 
        if (ToolClass.GetCharacterChatType(character.charCode) == ChatType.RANDCHAT)
        {
            // 마지막으로 한 것이 랜덤챗 종료 이벤트라면 더이상 진행하지 않음
            if (character.currentScriptCode!=0 && ToolClass.GetScript(character.currentScriptCode).scriptEventType == ScriptEventType.RANDOMCHAT_END)
            {
                character.currentScriptCode = 0;
                character.currentScriptPosition = 0;
                character.currentScriptProcess = 0f;
            }
            // 아니라면 다른거 찾긔
            else
            {
                ChatScript newScript;

                // 호감도를 다채웠고, 중복 스크립트 중이라면 End로 넘겨줌
                if (character.onOverlapScript && character.love >= 100)
                {
                    newScript = GetNewScript(character.charCode, -1, -1, ScriptEventType.RANDOMCHAT_END);
                }
                else
                {
                    newScript = GetNewScript(character.charCode, character.level, character.scriptPriority, ScriptEventType.NORMAL);
                    // 현재 prioity에 스크립트가 없다면
                    if (newScript == null)
                    {
                        character.scriptPriority += 1;
                        newScript = GetNewScript(character.charCode, character.level, character.scriptPriority, ScriptEventType.NORMAL);
                        // 모든 스크립트가 종료
                        if (newScript == null)
                        {
                            if (character.love >= 100)
                            {
                                newScript = GetNewScript(character.charCode, -1, -1, ScriptEventType.RANDOMCHAT_END);
                            }
                            else
                            {
                                character.onOverlapScript = true;
                                --character.scriptPriority;
                                newScript = GetNewScript(character.charCode, character.level, character.scriptPriority, ScriptEventType.NORMAL);
                            }
                        }
                    }
                }
                character.currentScriptCode = newScript.scriptCode;
                character.scriptCheck[ToolClass.GetScript(character.currentScriptCode).scriptCode] = true;
                character.currentScriptPosition = 0;
                character.currentScriptProcess = 0f;
            }
        }
        // 채팅 상태
        else if (ToolClass.GetCharacterChatType(character.charCode) == ChatType.CHAT)
        {
            // 중복 실행중에 호감도가 다 채워진다면 레벨을 올려주고 중복 실행 제거.
            if(character.onOverlapScript && character.love >= 100)
            {
                ++character.level;
                character.onOverlapScript = false;
            }

            ChatScript newScript;
            newScript = GetNewScript(character.charCode, character.level, character.scriptPriority, ScriptEventType.NORMAL);

            // 현재 priority에 스크립트가 없으면
            if (newScript == null)
            {
                character.scriptPriority += 1;
                newScript = GetNewScript(character.charCode, character.level, character.scriptPriority, ScriptEventType.NORMAL);
                // 더이상 우선순위가 없음.
                if(newScript == null)
                {
                    // 모든 스크립트가 종료
                    
                    // 호감도가 높다면 레벨을 올려줌.
                    if (character.love >= 100)
                    {
                        ++character.level;
                        character.scriptPriority = 0;
                        character.onOverlapScript = false;
                        newScript = GetNewScript(character.charCode, character.level, character.scriptPriority, ScriptEventType.NORMAL);

                        // 더이상 레벨이 없다.
                        if(newScript == null)
                        {
                            --character.level;
                            character.scriptCheck.Clear();
                            newScript = GetNewScript(character.charCode, character.level, character.scriptPriority, ScriptEventType.NORMAL);
                        }
                    }
                    // 호감도가 미달성이라면 중독 스크립트 실행하도록
                    else
                    {
                        character.scriptPriority -= 1;
                        character.onOverlapScript = true;
                        newScript = GetNewScript(character.charCode, character.level, character.scriptPriority, ScriptEventType.NORMAL);
                    }
                }
            }
            character.currentScriptCode = newScript.scriptCode;
            character.scriptCheck[ToolClass.GetScript(character.currentScriptCode).scriptCode] = true;
            character.currentScriptPosition = 0;
            character.currentScriptProcess = 0f;
        }
    }
    public void SendToChatLog(string script, int charCode)
    {
        switch (ToolClass.GetCharacterChatType(charCode))
        {
            case ChatType.CHAT:
                {
                    msg.AddToLog(charCode, script);
                    break;
                }
            case ChatType.RANDCHAT:
                {
                    rcm.AddToLog(charCode, script);
                    break;
                }
            case ChatType.NO_CHAT:
                throw new Exception("No chat but yes script...");
        }
    }
    ChatScript GetNewScript(int charCode, int level, int priority, ScriptEventType type)
    {
        // 같은 캐릭터 코드를 찾고,
        // 거기서 우선순위와 레벨을 매칭한뒤
        // 메인 퀘스트, 원타임 이벤트, 등등을 체크한다.
        List<ChatScript> mainScripts = new List<ChatScript>();
        List<ChatScript> subScripts = new List<ChatScript>();
        foreach (ChatScript script in mainData.scripts)
        {
            MyCharacter character = ToolClass.GetCharacter(charCode);
            if (type == script.scriptEventType &&
                charCode == script.charCode && // 캐릭터 코드가 같은가
                (level==-1 || level==script.level) && // 레벨이 같은가
                (priority==-1 || priority == script.priority) && // 우선순위가 같은가?
                (!script.isOnlyOneTime || !character.scriptCheck.ContainsKey(script.scriptCode) || 
                    (character.scriptCheck.ContainsKey(script.scriptCode) && character.scriptCheck[script.scriptCode]==false)) &&
                // 원타임이 아닌가? 또는 원타임을 클리어 하지 않았는가?
                (!character.scriptCheck.ContainsKey(script.scriptCode) || (character.scriptCheck.ContainsKey(script.scriptCode) && !character.scriptCheck[script.scriptCode]) ||
                (character.scriptCheck.ContainsKey(script.scriptCode) && character.scriptCheck[script.scriptCode] && character.onOverlapScript))
                ) // 이미 클리어했는데 자유선택인가? 또는 클리어하지 않았는가?
            {
                if (script.isMain)
                {
                    mainScripts.Add(script);
                }
                else
                {
                    subScripts.Add(script);
                }
            }
        }

        // 메인퀘스트가 존재
        if (mainScripts.Count >= 1)
        {
            return mainScripts[UnityEngine.Random.Range(0, mainScripts.Count)];
        }
        // 서브퀘스트가 존재
        else if(subScripts.Count >= 1)
        {
            return subScripts[UnityEngine.Random.Range(0, subScripts.Count)];
        }
        // 더이상 퀘스트가 존재하지 않음
        else
        {
            return null;
        }
    }

    void AppTouchRealese()
    {
        // Spawn Effect
        GameObject particle = Instantiate(pt_touchEnd, nowPoint, transform.rotation);
        Vector3 particle_pos = particle.transform.position;
        particle_pos.z = -5f;
        particle.transform.position = particle_pos;

        bOnTouch = false;
    }
    void TouchEffectProc()
    {
        // Touch Realese
        if (Input.touchCount == 0 && myTouchid != -1)
        {
            myTouchid = -1;

            if (bOnTouch)
            {
                AppTouchRealese();
            }
        }

        // Touch Start
        if (Input.touchCount > 0 && myTouchid == -1)
        {
            bOnTouch = true;

            // Set Touch Info
            Touch touch = Input.GetTouch(0);
            myTouchid = touch.fingerId;
            Vector2 touchDeltaPosition = touch.position;
            nowPoint = Camera.main.ScreenToWorldPoint(touchDeltaPosition);

        }
        // Touch Move
        else if (bOnTouch)
        {
            bool bNoTouchId = true;
            for (int i = 0; i < Input.touchCount; ++i)
            {
                Touch touch = Input.GetTouch(i);
                if (touch.fingerId == myTouchid)
                {
                    // My Touch
                    bNoTouchId = false;

                    // Set Touch Info
                    Vector2 touchDeltaPosition = touch.position;
                    nowPoint = Camera.main.ScreenToWorldPoint(touchDeltaPosition);

                    // Respawn Effect Proc
                    touchEffect_respawn -= Time.deltaTime;
                    if (touchEffect_respawn < 0f)
                    {
                        touchEffect_respawn = touchEffect_respawnTime;

                        // Spawn Effect
                        GameObject particle = Instantiate(pt_move, nowPoint, transform.rotation);
                        Vector3 particle_pos = particle.transform.position;
                        particle_pos.z = -5f;
                        particle.transform.position = particle_pos;
                    }

                    break;
                }
            }

            if (bNoTouchId)
            {
                AppTouchRealese();

            }
        }
    }
    private Vector3 GetCursorPos()
    {
        return Input.GetTouch(0).position;
    }

    private static GameMain instance;
    public static GameMain GetInstance()
    {
        if (!instance)
        {
            instance = GameObject.FindObjectOfType<GameMain>();
            if (!instance)
                Debug.LogError("There needs to be one active MyClass script on a GameObject in your scene.");
        }

        return instance;
    }
}