﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MyDesign;
using MyTool;

public class AppMain : MonoBehaviour
{
    [HideInInspector] public FadeOutSystem fos;
    [HideInInspector] public AppType appType;
    [HideInInspector] public Home myHome;
    [HideInInspector] public DockApp dockApp;
    [HideInInspector] public GameMain gm;

    public void Close()
    {
        myHome.fos.FadeIn();
        fos.SetType(FadeOutSystem.ChangeType.Zoom);
        fos.FadeOut();
    }

    public void SetAlram(int count)
    {
        dockApp.SetNotification(count);
    }

    public void Init(Home home, DockApp myApp)
    {
        myHome = home;
        dockApp = myApp;
        appType = dockApp.appType;
        fos = GetComponent<FadeOutSystem>();
        fos.Init(4f, false, 1f, true);
    }
}