﻿namespace Assets.SimpleAndroidNotifications
{
    public enum NotificationIcon
    {
        Bell,
        Clock,
        Event,
        Heart,
        Message,
        Star
    }
}