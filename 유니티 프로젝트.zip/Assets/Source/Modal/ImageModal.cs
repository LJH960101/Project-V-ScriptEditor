﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ImageModal : MonoBehaviour
{
    public void Init(Sprite sp)
    {
        transform.Find("Image").GetComponent<UnityEngine.UI.Image>().sprite = sp;
        transform.Find("Btn_Back").GetComponent<UnityEngine.UI.Button>().onClick.AddListener(Click);
        GetComponent<FadeOutSystem>().Init(4f, true, 1f, false);
        GetComponent<FadeOutSystem>().FadeIn();
    }
    public void Init(string text)
    {
        transform.Find("Image").GetComponent<UnityEngine.UI.Image>().sprite = Resources.Load<Sprite>("Image/" + text);
        transform.Find("Btn_Back").GetComponent<UnityEngine.UI.Button>().onClick.AddListener(Click);
        GetComponent<FadeOutSystem>().Init(4f, true, 1f, false);
        GetComponent<FadeOutSystem>().FadeIn();
    }
    public void Click()
    {
        GetComponent<FadeOutSystem>().FadeOut();
    }
}
