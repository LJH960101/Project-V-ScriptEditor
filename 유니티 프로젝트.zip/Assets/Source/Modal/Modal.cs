﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Modal : MonoBehaviour
{
    public GameObject okModal;
    public GameObject rcAlram;
    public GameObject msgAlram;
    public GameObject imageModal;
    public GameObject exitModal;
    public GameObject snsSelect;
    private static Modal instance;
    public static Modal GetInstance()
    {
        if (!instance)
        {
            instance = GameObject.FindObjectOfType<Modal>();
            if (!instance)
                Debug.LogError("There needs to be one active MyClass script on a GameObject in your scene.");
        }

        return instance;
    }
    public void CreateNewOkModal(string text)
    {
        if (!okModal) print("No okModal");
        else
        {
            Instantiate(okModal, transform).GetComponent<OkModal>().Init(text);
        }
    }
    public void CreateExitModal()
    {
        if (!exitModal) print("No exitModal");
        else
        {
            Instantiate(exitModal, transform).GetComponent<ExitModal>().Init();
        }
    }
    public void CreateRCAlram(string text, int charCode)
    {
        if (!rcAlram) print("No RCAlram");
        else
        {
            Instantiate(rcAlram, transform).GetComponent<RCAlram>().Init(text, charCode);
        }
    }
    public void CreateMSGAlram(string text, int charCode)
    {
        if (!msgAlram) print("No MSGAlram");
        else
        {
            Instantiate(msgAlram, transform).GetComponent<MSGAlram>().Init(text, charCode);
        }
    }
    public void CreateImageModal(string imagePath)
    {
        if (!imageModal) print("No imageModal");
        else
        {
            Instantiate(imageModal, transform).GetComponent<ImageModal>().Init(imagePath);
        }
    }
    public void CreateImageModal(Sprite sp)
    {
        if (!imageModal) print("No RCAlram");
        else
        {
            Instantiate(imageModal, transform).GetComponent<ImageModal>().Init(sp);
        }
    }
    public void CreateSnsSelect(string[] selects, SnsPost targetPost)
    {
        if (!snsSelect) print("No RCAlram");
        else
        {
            Instantiate(snsSelect, transform).GetComponent<SnsSelectModal>().Init(selects, targetPost);
        }
    }
}